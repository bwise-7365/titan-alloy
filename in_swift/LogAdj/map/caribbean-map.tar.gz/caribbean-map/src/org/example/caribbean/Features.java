package org.example.caribbean;

import org.example.caribbean.Geom.Bbox;
import org.example.caribbean.Geom.Feature;
import org.example.caribbean.Geom.LonLat;
import org.example.caribbean.Geom.Poly;
import org.example.caribbean.Geom.Ring;
import org.example.caribbean.Json.JArray;
import org.example.caribbean.Json.JNumber;
import org.example.caribbean.Json.JObject;
import org.example.caribbean.Json.JString;
import org.example.caribbean.Json.Value;

import java.util.ArrayList;
import java.util.List;

/**
 * Converts the GeoJSON value tree into our domain records, and splits
 * MultiPolygons into individual polygons so that, for example, the
 * Martinique and Guadeloupe parts of France can be filtered independently
 * of the European mainland by bounding-box intersection.
 */
public final class Features {

    private Features() { }

    /** Extracts all polygons from a FeatureCollection whose per-polygon bbox intersects the given keep box. */
    public static List<Feature> readAndClip(Value root, Bbox keep) {
        final JObject top = requireObject(root, "root");
        final JArray features = requireArray(top.entries().get("features"), "features");
        final List<Feature> out = new ArrayList<>();
        for (final Value v : features.items()) {
            final Feature f = readFeature(requireObject(v, "feature"), keep);
            if (!f.polygons().isEmpty()) {
                out.add(f);
            }
        }
        return out;
    }

    private static Feature readFeature(JObject feature, Bbox keep) {
        final JObject props = requireObject(feature.entries().get("properties"), "properties");
        final String name = optionalString(props.entries().get("NAME"), "(unnamed)");
        final String adm0a3 = optionalString(props.entries().get("ADM0_A3"), "");
        final Value geom = feature.entries().get("geometry");
        if (!(geom instanceof JObject geomObject)) {
            return new Feature(name, adm0a3, List.of());
        }
        final List<Poly> polygons = readGeometry(geomObject, keep);
        return new Feature(name, adm0a3, polygons);
    }

    private static List<Poly> readGeometry(JObject geom, Bbox keep) {
        final String type = requireString(geom.entries().get("type"), "geometry.type");
        final JArray coords = requireArray(geom.entries().get("coordinates"), "coordinates");
        final List<Poly> result = new ArrayList<>();
        if ("Polygon".equals(type)) {
            final Poly poly = readPolygon(coords);
            if (keepPoly(poly, keep)) {
                result.add(poly);
            }
        } else if ("MultiPolygon".equals(type)) {
            for (final Value v : coords.items()) {
                final Poly poly = readPolygon(requireArray(v, "polygon"));
                if (keepPoly(poly, keep)) {
                    result.add(poly);
                }
            }
        }
        // Points, LineStrings, etc. are silently ignored; we only want landmass.
        return result;
    }

    private static Poly readPolygon(JArray rings) {
        if (rings.items().isEmpty()) {
            throw new IllegalArgumentException("polygon has no rings");
        }
        final Ring outer = readRing(requireArray(rings.items().get(0), "outer ring"));
        final List<Ring> holes = new ArrayList<>();
        for (int i = 1; i < rings.items().size(); i++) {
            holes.add(readRing(requireArray(rings.items().get(i), "hole ring")));
        }
        return new Poly(outer, holes);
    }

    private static Ring readRing(JArray coords) {
        final List<LonLat> points = new ArrayList<>(coords.items().size());
        for (final Value v : coords.items()) {
            final JArray pair = requireArray(v, "coordinate pair");
            if (pair.items().size() < 2) {
                throw new IllegalArgumentException("coordinate pair has < 2 values");
            }
            final double lon = requireNumber(pair.items().get(0), "lon");
            final double lat = requireNumber(pair.items().get(1), "lat");
            points.add(new LonLat(lon, lat));
        }
        return new Ring(points);
    }

    private static boolean keepPoly(Poly poly, Bbox keep) {
        final Bbox polyBox = Bbox.ofLonLats(poly.outer().points());
        return polyBox.intersects(keep);
    }

    // --- small strict accessors ---------------------------------------------

    private static JObject requireObject(Value v, String context) {
        if (v instanceof JObject o) {
            return o;
        }
        throw new IllegalArgumentException(context + ": expected object, got " + typeOf(v));
    }

    private static JArray requireArray(Value v, String context) {
        if (v instanceof JArray a) {
            return a;
        }
        throw new IllegalArgumentException(context + ": expected array, got " + typeOf(v));
    }

    private static String requireString(Value v, String context) {
        if (v instanceof JString s) {
            return s.text();
        }
        throw new IllegalArgumentException(context + ": expected string, got " + typeOf(v));
    }

    private static double requireNumber(Value v, String context) {
        if (v instanceof JNumber n) {
            return n.value();
        }
        throw new IllegalArgumentException(context + ": expected number, got " + typeOf(v));
    }

    private static String optionalString(Value v, String fallback) {
        if (v instanceof JString s) {
            return s.text();
        }
        return fallback;
    }

    private static String typeOf(Value v) {
        if (v == null) {
            return "absent";
        }
        return v.getClass().getSimpleName();
    }
}
