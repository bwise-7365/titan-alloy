package org.example.caribbean;

import org.example.caribbean.Geom.LonLat;
import org.example.caribbean.Geom.XY;

/**
 * Spherical Web Mercator (EPSG:3857 sphere, Snyder 1987, p. 41).
 * Output units are radians on a unit sphere; callers normalize into
 * SVG pixel space using the projected bounding box.
 *
 * Reference: Snyder, J.P. (1987). "Map Projections — A Working Manual."
 * USGS Professional Paper 1395. Open access:
 *   https://pubs.er.usgs.gov/publication/pp1395
 */
public final class Mercator {

    private Mercator() { }

    /** Projects lon/lat (degrees) to planar x/y with y increasing northward. */
    public static XY project(LonLat p) {
        final double lonRad = Math.toRadians(p.lon());
        final double latRad = Math.toRadians(p.lat());
        final double x = lonRad;
        final double y = Math.log(Math.tan(Math.PI / 4.0 + latRad / 2.0));
        return new XY(x, y);
    }
}
