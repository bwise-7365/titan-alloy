package org.example.caribbean;

import org.example.caribbean.Geom.Bbox;
import org.example.caribbean.Geom.XY;

import java.io.PrintWriter;
import java.util.List;
import java.util.Locale;

/**
 * Streams an SVG document to a PrintWriter. The writer is agnostic about
 * meaning — it takes already-projected and already-simplified pixel rings.
 */
public final class SvgWriter {

    private final PrintWriter out;
    private final Bbox viewBox;
    private final int coordPrecision;

    public SvgWriter(PrintWriter out, Bbox viewBox, int coordPrecision) {
        if (coordPrecision < 0 || coordPrecision > 10) {
            throw new IllegalArgumentException("coordPrecision out of range: " + coordPrecision);
        }
        this.out = out;
        this.viewBox = viewBox;
        this.coordPrecision = coordPrecision;
    }

    public void open() {
        final double width = viewBox.maxX() - viewBox.minX();
        final double height = viewBox.maxY() - viewBox.minY();
        out.println("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
        out.printf(Locale.ROOT,
                "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"%s %s %s %s\">%n",
                fmt(viewBox.minX()), fmt(viewBox.minY()), fmt(width), fmt(height));
        out.println("  <style>");
        out.println("    .land { fill: #e8e0c8; stroke: #333; stroke-width: 0.5; stroke-linejoin: round; fill-rule: evenodd; }");
        out.println("    .sea  { fill: #cfe2f0; }");
        out.println("  </style>");
        out.printf(Locale.ROOT, "  <rect class=\"sea\" x=\"%s\" y=\"%s\" width=\"%s\" height=\"%s\"/>%n",
                fmt(viewBox.minX()), fmt(viewBox.minY()), fmt(width), fmt(height));
    }

    public void writePath(String id, String name, List<List<XY>> rings) {
        if (rings.isEmpty()) {
            return;
        }
        final StringBuilder d = new StringBuilder();
        for (final List<XY> ring : rings) {
            appendRing(d, ring);
        }
        out.printf(Locale.ROOT,
                "  <path class=\"land\" id=\"%s\" data-name=\"%s\" d=\"%s\"/>%n",
                xmlAttr(id), xmlAttr(name), d.toString());
    }

    public void close() {
        out.println("</svg>");
        out.flush();
    }

    private void appendRing(StringBuilder d, List<XY> ring) {
        if (ring.size() < 3) {
            return;
        }
        for (int i = 0; i < ring.size(); i++) {
            final XY p = ring.get(i);
            if (i == 0) {
                d.append('M');
            } else {
                d.append('L');
            }
            d.append(fmt(p.x())).append(',').append(fmt(p.y()));
            if (i < ring.size() - 1) {
                d.append(' ');
            }
        }
        d.append('Z');
    }

    private String fmt(double v) {
        return String.format(Locale.ROOT, "%." + coordPrecision + "f", v);
    }

    private static String xmlAttr(String s) {
        return s.replace("&", "&amp;").replace("\"", "&quot;").replace("<", "&lt;").replace(">", "&gt;");
    }
}
