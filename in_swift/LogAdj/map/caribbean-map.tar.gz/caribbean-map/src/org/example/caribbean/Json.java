package org.example.caribbean;

import java.io.IOException;
import java.io.Reader;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Minimal recursive-descent JSON parser — no external dependencies.
 * Supports the subset of JSON that GeoJSON uses.
 * Parse failures throw IllegalArgumentException with the offending position.
 *
 * Sealed value hierarchy so pattern-matching switches catch every case.
 */
public final class Json {

    private Json() { }

    public sealed interface Value permits JObject, JArray, JString, JNumber, JBool, JNull { }
    public record JObject(Map<String, Value> entries) implements Value { }
    public record JArray(List<Value> items) implements Value { }
    public record JString(String text) implements Value { }
    public record JNumber(double value) implements Value { }
    public record JBool(boolean value) implements Value { }
    public record JNull() implements Value { }

    public static Value parse(Reader reader) throws IOException {
        final String text = slurp(reader);
        final Parser parser = new Parser(text);
        parser.skipWhitespace();
        final Value value = parser.readValue();
        parser.skipWhitespace();
        if (parser.pos < parser.text.length()) {
            throw parser.fail("trailing content after top-level value");
        }
        return value;
    }

    private static String slurp(Reader reader) throws IOException {
        final StringBuilder builder = new StringBuilder(1 << 20);
        final char[] buffer = new char[1 << 16];
        int n;
        while ((n = reader.read(buffer)) >= 0) {
            builder.append(buffer, 0, n);
        }
        return builder.toString();
    }

    private static final class Parser {

        private final String text;
        private int pos;

        Parser(String text) {
            this.text = text;
            this.pos = 0;
        }

        Value readValue() {
            skipWhitespace();
            if (pos >= text.length()) {
                throw fail("unexpected end of input");
            }
            final char c = text.charAt(pos);
            if (c == '{') {
                return readObject();
            }
            if (c == '[') {
                return readArray();
            }
            if (c == '"') {
                return new JString(readString());
            }
            if (c == 't' || c == 'f') {
                return readBool();
            }
            if (c == 'n') {
                return readNull();
            }
            if (c == '-' || (c >= '0' && c <= '9')) {
                return readNumber();
            }
            throw fail("unexpected character '" + c + "'");
        }

        JObject readObject() {
            expect('{');
            final Map<String, Value> entries = new LinkedHashMap<>();
            skipWhitespace();
            if (peek() == '}') {
                pos++;
                return new JObject(entries);
            }
            while (true) {
                skipWhitespace();
                final String key = readString();
                skipWhitespace();
                expect(':');
                final Value value = readValue();
                entries.put(key, value);
                skipWhitespace();
                final char sep = readChar();
                if (sep == ',') {
                    continue;
                }
                if (sep == '}') {
                    return new JObject(entries);
                }
                throw fail("expected ',' or '}' but got '" + sep + "'");
            }
        }

        JArray readArray() {
            expect('[');
            final List<Value> items = new ArrayList<>();
            skipWhitespace();
            if (peek() == ']') {
                pos++;
                return new JArray(items);
            }
            while (true) {
                items.add(readValue());
                skipWhitespace();
                final char sep = readChar();
                if (sep == ',') {
                    continue;
                }
                if (sep == ']') {
                    return new JArray(items);
                }
                throw fail("expected ',' or ']' but got '" + sep + "'");
            }
        }

        String readString() {
            expect('"');
            final StringBuilder builder = new StringBuilder();
            while (pos < text.length()) {
                final char c = text.charAt(pos++);
                if (c == '"') {
                    return builder.toString();
                }
                if (c == '\\') {
                    if (pos >= text.length()) {
                        throw fail("unterminated escape");
                    }
                    final char esc = text.charAt(pos++);
                    switch (esc) {
                        case '"'  -> builder.append('"');
                        case '\\' -> builder.append('\\');
                        case '/'  -> builder.append('/');
                        case 'b'  -> builder.append('\b');
                        case 'f'  -> builder.append('\f');
                        case 'n'  -> builder.append('\n');
                        case 'r'  -> builder.append('\r');
                        case 't'  -> builder.append('\t');
                        case 'u'  -> builder.append(readUnicodeEscape());
                        default   -> { throw fail("invalid escape '\\" + esc + "'"); }
                    }
                    continue;
                }
                builder.append(c);
            }
            throw fail("unterminated string");
        }

        char readUnicodeEscape() {
            if (pos + 4 > text.length()) {
                throw fail("truncated \\u escape");
            }
            final String hex = text.substring(pos, pos + 4);
            pos += 4;
            try {
                return (char) Integer.parseInt(hex, 16);
            } catch (NumberFormatException e) {
                throw fail("invalid \\u escape '" + hex + "'");
            }
        }

        JNumber readNumber() {
            final int start = pos;
            if (peek() == '-') {
                pos++;
            }
            while (pos < text.length()) {
                final char c = text.charAt(pos);
                final boolean isDigit = c >= '0' && c <= '9';
                final boolean isExtra = c == '.' || c == 'e' || c == 'E' || c == '+' || c == '-';
                if (isDigit || isExtra) {
                    pos++;
                } else {
                    break;
                }
            }
            final String literal = text.substring(start, pos);
            try {
                return new JNumber(Double.parseDouble(literal));
            } catch (NumberFormatException e) {
                throw fail("invalid number '" + literal + "'");
            }
        }

        JBool readBool() {
            if (text.startsWith("true", pos)) {
                pos += 4;
                return new JBool(true);
            }
            if (text.startsWith("false", pos)) {
                pos += 5;
                return new JBool(false);
            }
            throw fail("expected true/false");
        }

        JNull readNull() {
            if (text.startsWith("null", pos)) {
                pos += 4;
                return new JNull();
            }
            throw fail("expected null");
        }

        void skipWhitespace() {
            while (pos < text.length()) {
                final char c = text.charAt(pos);
                if (c == ' ' || c == '\t' || c == '\n' || c == '\r') {
                    pos++;
                } else {
                    break;
                }
            }
        }

        char peek() {
            if (pos >= text.length()) {
                throw fail("unexpected end of input");
            }
            return text.charAt(pos);
        }

        char readChar() {
            if (pos >= text.length()) {
                throw fail("unexpected end of input");
            }
            return text.charAt(pos++);
        }

        void expect(char c) {
            final char actual = readChar();
            if (actual != c) {
                throw fail("expected '" + c + "' but got '" + actual + "'");
            }
        }

        IllegalArgumentException fail(String message) {
            return new IllegalArgumentException("JSON parse error at position " + pos + ": " + message);
        }
    }
}
