package org.example.caribbean;

import org.example.caribbean.Geom.Bbox;
import org.example.caribbean.Geom.Feature;
import org.example.caribbean.Geom.LonLat;
import org.example.caribbean.Geom.Poly;
import org.example.caribbean.Geom.Ring;
import org.example.caribbean.Geom.XY;
import org.example.caribbean.Json.Value;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

/**
 * Pipeline entry point:
 *   1. parse GeoJSON,
 *   2. clip by Caribbean lon/lat bbox,
 *   3. project to Web Mercator,
 *   4. simplify each ring with Douglas-Peucker,
 *   5. normalize into an SVG viewBox,
 *   6. emit SVG.
 *
 * Deliberately not using Map.merge / getOrDefault: when an option is absent
 * we want a hard failure rather than a silent default.
 */
public final class Main {

    public static void main(String[] args) throws IOException {
        final Args parsed = Args.parse(args);

        final Value root;
        try (BufferedReader reader = Files.newBufferedReader(parsed.input, StandardCharsets.UTF_8)) {
            root = Json.parse(reader);
        }

        final Bbox lonLatBox = new Bbox(parsed.minLon, parsed.minLat, parsed.maxLon, parsed.maxLat);
        final List<Feature> features = Features.readAndClip(root, lonLatBox);
        System.err.println("features retained: " + features.size());

        final List<ProjectedPoly> projected = projectAll(features);
        final List<ProjectedPoly> simplified = simplifyAll(projected, parsed.epsilon);
        final int kept = countPoints(simplified);
        final int raw = countPoints(projected);
        System.err.printf("points: raw=%d  simplified=%d  (%.1f%% retained)%n",
                raw, kept, 100.0 * kept / Math.max(1, raw));

        final Bbox worldBox = worldBoundsOf(simplified);
        final List<ProjectedPoly> pixels = normalize(simplified, worldBox, parsed.width, parsed.height);
        final Bbox viewBox = new Bbox(0, 0, parsed.width, parsed.height);

        try (PrintWriter out = new PrintWriter(Files.newBufferedWriter(parsed.output, StandardCharsets.UTF_8))) {
            final SvgWriter svg = new SvgWriter(out, viewBox, parsed.precision);
            svg.open();
            for (final ProjectedPoly p : pixels) {
                svg.writePath(p.id, p.name, p.rings);
            }
            svg.close();
        }
        System.err.println("wrote " + parsed.output.toAbsolutePath());
    }

    // --- internal working types ---------------------------------------------

    private record ProjectedPoly(String id, String name, List<List<XY>> rings) { }

    private static List<ProjectedPoly> projectAll(List<Feature> features) {
        final List<ProjectedPoly> out = new ArrayList<>();
        for (final Feature f : features) {
            int polyIndex = 0;
            for (final Poly poly : f.polygons()) {
                final List<List<XY>> rings = new ArrayList<>();
                rings.add(projectRing(poly.outer()));
                for (final Ring hole : poly.holes()) {
                    rings.add(projectRing(hole));
                }
                final String id = (f.adm0a3().isEmpty() ? f.name() : f.adm0a3()) + "-" + polyIndex;
                out.add(new ProjectedPoly(id, f.name(), rings));
                polyIndex++;
            }
        }
        return out;
    }

    private static List<XY> projectRing(Ring ring) {
        final List<XY> pts = new ArrayList<>(ring.points().size());
        for (final LonLat p : ring.points()) {
            pts.add(Mercator.project(p));
        }
        return pts;
    }

    private static List<ProjectedPoly> simplifyAll(List<ProjectedPoly> polys, double epsilon) {
        if (epsilon == 0.0) {
            return polys;
        }
        final List<ProjectedPoly> out = new ArrayList<>(polys.size());
        for (final ProjectedPoly p : polys) {
            final List<List<XY>> simplifiedRings = new ArrayList<>(p.rings.size());
            for (final List<XY> ring : p.rings) {
                simplifiedRings.add(Simplify.douglasPeucker(ring, epsilon));
            }
            out.add(new ProjectedPoly(p.id, p.name, simplifiedRings));
        }
        return out;
    }

    private static Bbox worldBoundsOf(List<ProjectedPoly> polys) {
        final List<XY> all = new ArrayList<>();
        for (final ProjectedPoly p : polys) {
            for (final List<XY> ring : p.rings) {
                all.addAll(ring);
            }
        }
        return Bbox.ofXYs(all);
    }

    private static List<ProjectedPoly> normalize(List<ProjectedPoly> polys, Bbox world, double width, double height) {
        final double worldW = world.maxX() - world.minX();
        final double worldH = world.maxY() - world.minY();
        final double scale = Math.min(width / worldW, height / worldH);
        final double offsetX = (width  - scale * worldW) * 0.5;
        final double offsetY = (height - scale * worldH) * 0.5;
        final List<ProjectedPoly> out = new ArrayList<>(polys.size());
        for (final ProjectedPoly p : polys) {
            final List<List<XY>> transformedRings = new ArrayList<>(p.rings.size());
            for (final List<XY> ring : p.rings) {
                final List<XY> transformed = new ArrayList<>(ring.size());
                for (final XY xy : ring) {
                    final double px = offsetX + scale * (xy.x() - world.minX());
                    // SVG y axis increases downward; Mercator y increases northward, so flip.
                    final double py = offsetY + scale * (world.maxY() - xy.y());
                    transformed.add(new XY(px, py));
                }
                transformedRings.add(transformed);
            }
            out.add(new ProjectedPoly(p.id, p.name, transformedRings));
        }
        return out;
    }

    private static int countPoints(List<ProjectedPoly> polys) {
        int n = 0;
        for (final ProjectedPoly p : polys) {
            for (final List<XY> ring : p.rings) {
                n += ring.size();
            }
        }
        return n;
    }

    // --- argument parsing ---------------------------------------------------

    private record Args(Path input, Path output,
                        double minLon, double minLat, double maxLon, double maxLat,
                        double epsilon, double width, double height, int precision) {

        static Args parse(String[] raw) {
            Path input = null;
            Path output = null;
            double minLon = -85.5, minLat = 10.0, maxLon = -60.5, maxLat = 23.5;
            double epsilon = 1.0e-4;
            double width = 1200.0, height = 600.0;
            int precision = 2;

            int i = 0;
            while (i < raw.length) {
                final String flag = raw[i++];
                final String value = (i < raw.length) ? raw[i++] : missing(flag);
                switch (flag) {
                    case "--input"     -> input     = Path.of(value);
                    case "--output"    -> output    = Path.of(value);
                    case "--min-lon"   -> minLon    = Double.parseDouble(value);
                    case "--min-lat"   -> minLat    = Double.parseDouble(value);
                    case "--max-lon"   -> maxLon    = Double.parseDouble(value);
                    case "--max-lat"   -> maxLat    = Double.parseDouble(value);
                    case "--epsilon"   -> epsilon   = Double.parseDouble(value);
                    case "--width"     -> width     = Double.parseDouble(value);
                    case "--height"    -> height    = Double.parseDouble(value);
                    case "--precision" -> precision = Integer.parseInt(value);
                    default            -> { throw new IllegalArgumentException("unknown flag: " + flag); }
                }
            }
            if (input == null || output == null) {
                throw new IllegalArgumentException("--input and --output are required");
            }
            return new Args(input, output, minLon, minLat, maxLon, maxLat, epsilon, width, height, precision);
        }

        private static String missing(String flag) {
            throw new IllegalArgumentException("missing value for " + flag);
        }
    }
}
