package org.example.caribbean;

import org.example.caribbean.Geom.XY;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.List;

/**
 * Ramer–Douglas–Peucker polyline simplification (iterative stack, so deep
 * rings do not blow the JVM call stack).
 *
 * References:
 *   Douglas, D.H. &amp; Peucker, T.K. (1973). "Algorithms for the reduction
 *   of the number of points required to represent a digitized line or its
 *   caricature." Cartographica, 10(2), 112–122.
 *     https://doi.org/10.3138/FM57-6770-U75U-7727
 *
 *   For an empirical comparison of simplification algorithms on coastline
 *   data, see: Shi, W. &amp; Cheung, C. (2006). "Performance Evaluation of
 *   Line Simplification Algorithms for Vector Generalization." The
 *   Cartographic Journal, 43(1), 27–44.
 *     https://doi.org/10.1179/000870406X93490
 *
 * Epsilon is measured in the same units as the input points. For the
 * Web Mercator radians used by {@link Mercator}, useful values live
 * roughly in the range 1e-5 (barely any simplification) to 5e-3
 * (aggressive generalization).
 */
public final class Simplify {

    private Simplify() { }

    /**
     * Returns a simplified copy of the given ring. The first and last
     * points of the returned list are the same object references as the
     * input's first and last points, so a closed ring stays closed.
     */
    public static List<XY> douglasPeucker(List<XY> points, double epsilon) {
        if (epsilon < 0.0) {
            throw new IllegalArgumentException("epsilon must be >= 0: " + epsilon);
        }
        final int n = points.size();
        if (n < 3) {
            return new ArrayList<>(points);
        }
        final boolean[] keep = new boolean[n];
        keep[0] = true;
        keep[n - 1] = true;

        final Deque<int[]> stack = new ArrayDeque<>();
        stack.push(new int[] { 0, n - 1 });

        final double epsilonSquared = epsilon * epsilon;
        while (!stack.isEmpty()) {
            final int[] segment = stack.pop();
            final int start = segment[0];
            final int end = segment[1];
            final int farthest = indexOfFarthestPoint(points, start, end);
            if (farthest < 0) {
                continue;
            }
            final double maxDistSquared = perpendicularDistanceSquared(
                    points.get(farthest), points.get(start), points.get(end));
            if (maxDistSquared > epsilonSquared) {
                keep[farthest] = true;
                if (farthest - start > 1) {
                    stack.push(new int[] { start, farthest });
                }
                if (end - farthest > 1) {
                    stack.push(new int[] { farthest, end });
                }
            }
        }

        final List<XY> out = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            if (keep[i]) {
                out.add(points.get(i));
            }
        }
        return out;
    }

    /** Returns the index in (start, end) of the point farthest from the chord, or -1 if none exists. */
    private static int indexOfFarthestPoint(List<XY> points, int start, int end) {
        if (end - start < 2) {
            return -1;
        }
        final XY a = points.get(start);
        final XY b = points.get(end);
        double best = -1.0;
        int bestIndex = -1;
        for (int i = start + 1; i < end; i++) {
            final double d = perpendicularDistanceSquared(points.get(i), a, b);
            if (d > best) {
                best = d;
                bestIndex = i;
            }
        }
        return bestIndex;
    }

    /**
     * Squared perpendicular distance from point p to the line through a and b.
     * Degenerate chord (a == b) falls back to squared distance from p to a.
     */
    private static double perpendicularDistanceSquared(XY p, XY a, XY b) {
        final double dx = b.x() - a.x();
        final double dy = b.y() - a.y();
        final double lengthSquared = dx * dx + dy * dy;
        if (lengthSquared == 0.0) {
            final double ex = p.x() - a.x();
            final double ey = p.y() - a.y();
            return ex * ex + ey * ey;
        }
        final double cross = dx * (a.y() - p.y()) - (a.x() - p.x()) * dy;
        return (cross * cross) / lengthSquared;
    }
}
