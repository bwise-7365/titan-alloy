package org.example.caribbean;

import java.util.List;

/**
 * Immutable geometry records used throughout the pipeline.
 * All coordinates are doubles; conventions are stated per-record.
 */
public final class Geom {

    private Geom() { }

    /** Geographic point in decimal degrees. Longitude first to match GeoJSON. */
    public record LonLat(double lon, double lat) { }

    /** Projected point in arbitrary planar units. */
    public record XY(double x, double y) { }

    /** A closed linear ring. The first and last points are expected to coincide in GeoJSON; this class does not enforce it. */
    public record Ring(List<LonLat> points) { }

    /** A polygon with an outer ring and zero or more holes. */
    public record Poly(Ring outer, List<Ring> holes) { }

    /** A named feature carrying one or more polygon rings (a MultiPolygon in GeoJSON terms). */
    public record Feature(String name, String adm0a3, List<Poly> polygons) { }

    /** Axis-aligned bounding box in whatever units the caller supplies. */
    public record Bbox(double minX, double minY, double maxX, double maxY) {

        public boolean intersects(Bbox other) {
            if (this.maxX < other.minX) {
                return false;
            }
            if (this.minX > other.maxX) {
                return false;
            }
            if (this.maxY < other.minY) {
                return false;
            }
            if (this.minY > other.maxY) {
                return false;
            }
            return true;
        }

        public static Bbox ofLonLats(List<LonLat> points) {
            if (points.isEmpty()) {
                throw new IllegalArgumentException("cannot compute bbox of empty point list");
            }
            double minLon = Double.POSITIVE_INFINITY;
            double maxLon = Double.NEGATIVE_INFINITY;
            double minLat = Double.POSITIVE_INFINITY;
            double maxLat = Double.NEGATIVE_INFINITY;
            for (final LonLat p : points) {
                if (p.lon() < minLon) { minLon = p.lon(); }
                if (p.lon() > maxLon) { maxLon = p.lon(); }
                if (p.lat() < minLat) { minLat = p.lat(); }
                if (p.lat() > maxLat) { maxLat = p.lat(); }
            }
            return new Bbox(minLon, minLat, maxLon, maxLat);
        }

        public static Bbox ofXYs(List<XY> points) {
            if (points.isEmpty()) {
                throw new IllegalArgumentException("cannot compute bbox of empty point list");
            }
            double minX = Double.POSITIVE_INFINITY;
            double maxX = Double.NEGATIVE_INFINITY;
            double minY = Double.POSITIVE_INFINITY;
            double maxY = Double.NEGATIVE_INFINITY;
            for (final XY p : points) {
                if (p.x() < minX) { minX = p.x(); }
                if (p.x() > maxX) { maxX = p.x(); }
                if (p.y() < minY) { minY = p.y(); }
                if (p.y() > maxY) { maxY = p.y(); }
            }
            return new Bbox(minX, minY, maxX, maxY);
        }
    }
}
