# caribbean-map

Pipeline for producing a simplified SVG map of the Caribbean from Natural Earth
1:50m admin-0 country polygons. Pure Java 17, no external JAR dependencies, Ant build.

## Pipeline

1. **Load** `ne_50m_admin_0_countries.geojson` with a hand-rolled recursive-descent JSON parser (`Json.java`).
2. **Clip** every polygon (not every feature — MultiPolygons are split first, so Martinique and Guadeloupe get separated from mainland France) against a lon/lat bounding box. Default: lon ∈ [-85.5, -60.5], lat ∈ [10.0, 23.5].
3. **Project** each point with spherical Web Mercator (`Mercator.java`).
4. **Simplify** each ring with Ramer–Douglas–Peucker using an iterative stack (`Simplify.java`). Epsilon is in Mercator radians.
5. **Normalize** into pixel space with uniform scale preserving aspect ratio, then flip the y axis into SVG orientation.
6. **Emit** SVG with one `<path>` per polygon ring set. `fill-rule: evenodd` so that polygon holes render correctly.

## Data source

- Natural Earth 1:50m Admin 0 Countries, public domain.
  - Landing page: <https://www.naturalearthdata.com/downloads/50m-cultural-vectors/>
  - Pre-converted GeoJSON mirror (what this tool expects):
    <https://raw.githubusercontent.com/nvkelso/natural-earth-vector/master/geojson/ne_50m_admin_0_countries.geojson>
  - License: public domain. See <https://www.naturalearthdata.com/about/terms-of-use/>.

Download once:

```sh
curl -L -o data/ne_50m_admin_0_countries.geojson \
  https://raw.githubusercontent.com/nvkelso/natural-earth-vector/master/geojson/ne_50m_admin_0_countries.geojson
```

## References

- Douglas, D.H. & Peucker, T.K. (1973). *Algorithms for the reduction of the number of points required to represent a digitized line or its caricature.* Cartographica 10(2), 112–122. <https://doi.org/10.3138/FM57-6770-U75U-7727>
- Snyder, J.P. (1987). *Map Projections — A Working Manual.* USGS Professional Paper 1395. <https://pubs.er.usgs.gov/publication/pp1395>
- For an alternative simplification algorithm that preserves small areas better than Douglas-Peucker (useful if the named tiny islands like St Vincent start disappearing at aggressive epsilon), see:
  Visvalingam, M. & Whyatt, J.D. (1993). *Line generalisation by repeated elimination of points.* Cartographic Journal 30(1), 46–51. <https://doi.org/10.1179/caj.1993.30.1.46>

## Build and run

```sh
ant jar
ant run -Dinput=data/ne_50m_admin_0_countries.geojson \
        -Doutput=caribbean.svg \
        -Depsilon=2.0e-4
```

Or invoke directly with the full flag set:

```sh
java -jar dist/caribbean-map.jar \
     --input data/ne_50m_admin_0_countries.geojson \
     --output caribbean.svg \
     --min-lon -85.5 --max-lon -60.5 \
     --min-lat 10.0  --max-lat 23.5 \
     --epsilon 2.0e-4 \
     --width 1200 --height 600 \
     --precision 2
```

## Tuning the simplification

In Mercator radians, very roughly:

| epsilon  | character                                                |
|----------|----------------------------------------------------------|
| 0        | no simplification; raw Natural Earth 1:50m detail        |
| 1.0e-5   | imperceptible smoothing                                  |
| 1.0e-4   | noticeable smoothing on Cuba's coast, small islands intact |
| 5.0e-4   | cartoon-grade outlines, tiniest islands may collapse      |
| 2.0e-3   | near-caricature                                          |

Because Douglas-Peucker uses maximum perpendicular distance, at large epsilon the smallest islands (St Vincent, the Grenadines, parts of Guadeloupe) can shrink to fewer than 3 points and the `SvgWriter` will drop them. If that becomes a problem, swap in a Visvalingam-Whyatt pass keyed on minimum triangle area — it preserves small features better.

## Layout

```
caribbean-map/
├── build.xml
├── README.md
├── data/
│   └── ne_50m_admin_0_countries.geojson   (not checked in)
└── src/org/example/caribbean/
    ├── Json.java          — sealed-interface JSON AST + parser
    ├── Geom.java          — LonLat, XY, Ring, Poly, Feature, Bbox
    ├── Features.java      — GeoJSON → Feature, with per-polygon bbox clipping
    ├── Mercator.java      — spherical Web Mercator
    ├── Simplify.java      — iterative Douglas-Peucker
    ├── SvgWriter.java     — SVG emitter
    └── Main.java          — CLI, pipeline glue
```

Everything is split; no file exceeds ~250 lines.
