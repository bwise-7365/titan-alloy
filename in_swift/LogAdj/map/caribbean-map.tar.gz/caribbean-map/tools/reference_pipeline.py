#!/usr/bin/env python3
"""
Reference implementation of the Caribbean-map pipeline in Python.
Mirrors the Java code one-for-one so we can validate the algorithm
without needing a JDK installed. If this script produces a valid SVG
on the test GeoJSON, the Java port will behave the same way.
"""
import json
import math
import sys


def project_mercator(lon, lat):
    """Spherical Web Mercator: lon/lat degrees -> x/y radians."""
    x = math.radians(lon)
    y = math.log(math.tan(math.pi / 4.0 + math.radians(lat) / 2.0))
    return (x, y)


def perp_dist_sq(p, a, b):
    dx = b[0] - a[0]
    dy = b[1] - a[1]
    length_sq = dx * dx + dy * dy
    if length_sq == 0.0:
        ex = p[0] - a[0]
        ey = p[1] - a[1]
        return ex * ex + ey * ey
    cross = dx * (a[1] - p[1]) - (a[0] - p[0]) * dy
    return (cross * cross) / length_sq


def douglas_peucker(points, epsilon):
    """Iterative Douglas-Peucker. Returns simplified point list."""
    n = len(points)
    if n < 3:
        return list(points)
    keep = [False] * n
    keep[0] = True
    keep[n - 1] = True
    stack = [(0, n - 1)]
    eps_sq = epsilon * epsilon
    while stack:
        start, end = stack.pop()
        if end - start < 2:
            continue
        a, b = points[start], points[end]
        best, best_idx = -1.0, -1
        for i in range(start + 1, end):
            d = perp_dist_sq(points[i], a, b)
            if d > best:
                best, best_idx = d, i
        if best_idx >= 0 and best > eps_sq:
            keep[best_idx] = True
            if best_idx - start > 1:
                stack.append((start, best_idx))
            if end - best_idx > 1:
                stack.append((best_idx, end))
    return [p for p, k in zip(points, keep) if k]


def bbox_of(points):
    xs = [p[0] for p in points]
    ys = [p[1] for p in points]
    return (min(xs), min(ys), max(xs), max(ys))


def bboxes_intersect(a, b):
    return not (a[2] < b[0] or a[0] > b[2] or a[3] < b[1] or a[1] > b[3])


def extract_polygons(feature, keep_box):
    """Flatten a feature into (name, adm0a3, [outer_ring, *holes]) per polygon."""
    props = feature.get("properties", {})
    name = props.get("NAME", "(unnamed)")
    adm = props.get("ADM0_A3", "")
    geom = feature.get("geometry")
    if not geom:
        return
    gtype = geom["type"]
    coords = geom["coordinates"]
    if gtype == "Polygon":
        polys = [coords]
    elif gtype == "MultiPolygon":
        polys = coords
    else:
        return
    for poly in polys:
        outer = [(p[0], p[1]) for p in poly[0]]
        if not bboxes_intersect(bbox_of(outer), keep_box):
            continue
        rings = [outer]
        for hole in poly[1:]:
            rings.append([(p[0], p[1]) for p in hole])
        yield (name, adm, rings)


def main():
    src = sys.argv[1] if len(sys.argv) > 1 else "data/test_islands.geojson"
    dst = sys.argv[2] if len(sys.argv) > 2 else "test_out.svg"
    epsilon = float(sys.argv[3]) if len(sys.argv) > 3 else 0.0

    # Caribbean bbox.
    keep_box = (-85.5, 10.0, -60.5, 23.5)
    width, height = 1200.0, 600.0

    with open(src) as f:
        root = json.load(f)

    # Extract and clip.
    polys = []
    for feat in root["features"]:
        for name, adm, rings in extract_polygons(feat, keep_box):
            polys.append((name, adm, rings))
    sys.stderr.write(f"polygons retained: {len(polys)}\n")

    # Project.
    projected = []
    for name, adm, rings in polys:
        proj_rings = [[project_mercator(*p) for p in r] for r in rings]
        projected.append((name, adm, proj_rings))

    # Simplify.
    simplified = []
    raw_n = sum(len(r) for _, _, rs in projected for r in rs)
    for name, adm, rings in projected:
        new_rings = [douglas_peucker(r, epsilon) for r in rings]
        simplified.append((name, adm, new_rings))
    kept_n = sum(len(r) for _, _, rs in simplified for r in rs)
    sys.stderr.write(f"points: raw={raw_n} simplified={kept_n} "
                     f"({100.0 * kept_n / max(1, raw_n):.1f}% retained)\n")

    # World bbox.
    all_pts = [p for _, _, rs in simplified for r in rs for p in r]
    wx_min, wy_min, wx_max, wy_max = bbox_of(all_pts)
    ww, wh = wx_max - wx_min, wy_max - wy_min
    scale = min(width / ww, height / wh)
    off_x = (width - scale * ww) * 0.5
    off_y = (height - scale * wh) * 0.5

    def to_px(p):
        px = off_x + scale * (p[0] - wx_min)
        py = off_y + scale * (wy_max - p[1])
        return (px, py)

    # Emit SVG.
    with open(dst, "w") as out:
        out.write('<?xml version="1.0" encoding="UTF-8"?>\n')
        out.write(f'<svg xmlns="http://www.w3.org/2000/svg" '
                  f'viewBox="0 0 {width:.0f} {height:.0f}">\n')
        out.write('  <style>\n')
        out.write('    .land { fill: #e8e0c8; stroke: #333; stroke-width: 0.5; '
                  'stroke-linejoin: round; fill-rule: evenodd; }\n')
        out.write('    .sea  { fill: #cfe2f0; }\n')
        out.write('  </style>\n')
        out.write(f'  <rect class="sea" x="0" y="0" '
                  f'width="{width:.0f}" height="{height:.0f}"/>\n')

        idx = 0
        for name, adm, rings in simplified:
            d = []
            for r in rings:
                if len(r) < 3:
                    continue
                parts = []
                for i, pt in enumerate(r):
                    px, py = to_px(pt)
                    cmd = "M" if i == 0 else "L"
                    parts.append(f"{cmd}{px:.2f},{py:.2f}")
                d.append(" ".join(parts) + "Z")
            if not d:
                continue
            poly_id = (adm or name) + f"-{idx}"
            out.write(f'  <path class="land" id="{poly_id}" '
                      f'data-name="{name}" d="{" ".join(d)}"/>\n')
            idx += 1
        out.write('</svg>\n')
    sys.stderr.write(f"wrote {dst}\n")


if __name__ == "__main__":
    main()
